import dotenv from "dotenv";

dotenv.config();

const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const HUGGINGFACE_API_URL = "https://api-inference.huggingface.co/models/ibm-granite/granite-3.0-8b-instruct";

export class AIService {
  private static async callGroq(prompt: string, systemInstruction: string = "You are a helpful branding assistant.") {
    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) {
      throw new Error("GROQ_API_KEY is not set");
    }

    const response = await fetch(GROQ_API_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages: [
          { role: "system", content: systemInstruction },
          { role: "user", content: prompt },
        ],
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`Groq API error: ${JSON.stringify(error)}`);
    }

    const data = await response.json();
    return data.choices[0].message.content;
  }

  private static async callHuggingFace(prompt: string) {
    const apiKey = process.env.HUGGINGFACE_API_KEY;
    if (!apiKey) {
      throw new Error("HUGGINGFACE_API_KEY is not set");
    }

    const response = await fetch(HUGGINGFACE_API_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: `<|system|>\nYou are a professional branding expert.\n<|user|>\n${prompt}\n<|assistant|>\n`,
        parameters: {
          max_new_tokens: 500,
          return_full_text: false,
        }
      }),
    });

    if (response.status === 503) {
      return "The AI model is currently warming up on HuggingFace. Please try again in a few seconds, or I will use my backup brain if you ask again.";
    }

    if (!response.ok) {
      const error = await response.json();
      throw new Error(`HuggingFace API error: ${JSON.stringify(error)}`);
    }

    const data = await response.json();
    if (Array.isArray(data)) {
      return data[0].generated_text || data[0].text || "I couldn't generate a response.";
    }
    return data.generated_text || data.text || "I couldn't generate a response.";
  }

  static async generateBrandNames(industry: string, keywords: string, tone: string) {
    const prompt = `Generate 10 creative and unique brand name suggestions for the following:
    Industry: ${industry}
    Keywords: ${keywords}
    Tone: ${tone}
    
    Return only the list of names, one per line.`;
    
    const result = await this.callGroq(prompt, "You are an expert brand naming consultant.");
    return result.split("\n").filter((name: string) => name.trim() !== "").map((name: string) => name.replace(/^\d+\.\s*/, "").trim());
  }

  static async generateMarketingContent(description: string, tone: string, type: string) {
    const prompt = `Generate a ${type} for the following brand:
    Description: ${description}
    Tone: ${tone}
    
    Provide high-quality, engaging content.`;
    
    return await this.callGroq(prompt, "You are a professional copywriter.");
  }

  static async analyzeSentiment(text: string) {
    const prompt = `Analyze the sentiment of the following review:
    "${text}"
    
    Return the result in JSON format:
    {
      "sentiment": "positive" | "neutral" | "negative",
      "explanation": "Brief explanation of why"
    }`;
    
    const result = await this.callGroq(prompt, "You are a sentiment analysis expert. Always return valid JSON.");
    try {
      // Extract JSON if there's markdown
      const jsonMatch = result.match(/\{[\s\S]*\}/);
      return JSON.parse(jsonMatch ? jsonMatch[0] : result);
    } catch (e) {
      return { sentiment: "unknown", explanation: "Failed to parse AI response" };
    }
  }

  static async generateColorPalette(industry: string, tone: string) {
    const prompt = `Suggest a color palette (3-5 colors) for a brand in the ${industry} industry with a ${tone} tone.
    Return the result as a JSON array of objects with "hex" and "name" properties.
    Example: [{"hex": "#FF5733", "name": "Sunset Orange"}]`;
    
    const result = await this.callGroq(prompt, "You are a professional brand designer. Always return valid JSON.");
    try {
      const jsonMatch = result.match(/\[[\s\S]*\]/);
      return JSON.parse(jsonMatch ? jsonMatch[0] : result);
    } catch (e) {
      return [];
    }
  }

  static async chatbotResponse(question: string) {
    try {
      // Try IBM Granite via HuggingFace first
      const response = await this.callHuggingFace(question);
      if (response.includes("warming up")) return response;
      return response;
    } catch (error) {
      console.error("HuggingFace failed, falling back to Groq:", error);
      // Fallback to Llama 3.3 on Groq
      const prompt = `You are a branding expert. A user asked: "${question}". Provide a helpful, professional response.`;
      return await this.callGroq(prompt, "You are a branding strategy expert.");
    }
  }

  static async generateLogoPrompt(brandName: string, industry: string, keywords: string) {
    const prompt = `Create a professional logo design prompt for Stable Diffusion XL for the following brand:
    Brand Name: ${brandName}
    Industry: ${industry}
    Keywords: ${keywords}
    
    The prompt should be detailed, specifying style, colors, composition, and mood. Avoid text in the logo if possible, focus on the icon/symbol.`;
    
    return await this.callGroq(prompt, "You are a professional logo designer and prompt engineer.");
  }
}
