import { Router } from "express";
import { AIService } from "../services/aiService";
import { z } from "zod";

const router = Router();

const BrandSchema = z.object({
  industry: z.string().min(1),
  keywords: z.string().min(1),
  tone: z.string().min(1),
});

router.post("/generate", async (req, res) => {
  try {
    const { industry, keywords, tone } = BrandSchema.parse(req.body);
    const names = await AIService.generateBrandNames(industry, keywords, tone);
    res.json({ names });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

export default router;
