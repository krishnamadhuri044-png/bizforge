import { Router } from "express";
import { AIService } from "../services/aiService";
import { z } from "zod";

const router = Router();

const SentimentSchema = z.object({
  text: z.string().min(1),
});

router.post("/analyze", async (req, res) => {
  try {
    const { text } = SentimentSchema.parse(req.body);
    const result = await AIService.analyzeSentiment(text);
    res.json(result);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

export default router;
