import { Router } from "express";
import { AIService } from "../services/aiService";
import { z } from "zod";

const router = Router();

const LogoSchema = z.object({
  brandName: z.string().min(1),
  industry: z.string().min(1),
  keywords: z.string().min(1),
});

router.post("/generate", async (req, res) => {
  try {
    const { brandName, industry, keywords } = LogoSchema.parse(req.body);
    const prompt = await AIService.generateLogoPrompt(brandName, industry, keywords);
    res.json({ prompt });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

export default router;
