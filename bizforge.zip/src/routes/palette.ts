import { Router } from "express";
import { AIService } from "../services/aiService";
import { z } from "zod";

const router = Router();

const PaletteSchema = z.object({
  industry: z.string().min(1),
  tone: z.string().min(1),
});

router.post("/generate", async (req, res) => {
  try {
    const { industry, tone } = PaletteSchema.parse(req.body);
    const palette = await AIService.generateColorPalette(industry, tone);
    res.json({ palette });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

export default router;
