import { Router } from "express";
import { AIService } from "../services/aiService";
import { z } from "zod";

const router = Router();

const MarketingSchema = z.object({
  description: z.string().min(1),
  tone: z.string().min(1),
  type: z.string().min(1),
});

router.post("/generate", async (req, res) => {
  try {
    const { description, tone, type } = MarketingSchema.parse(req.body);
    const content = await AIService.generateMarketingContent(description, tone, type);
    res.json({ content });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

export default router;
