import { Router } from "express";
import { AIService } from "../services/aiService";
import { z } from "zod";

const router = Router();

const ChatSchema = z.object({
  question: z.string().min(1),
});

router.post("/ask", async (req, res) => {
  try {
    const { question } = ChatSchema.parse(req.body);
    const response = await AIService.chatbotResponse(question);
    res.json({ response });
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

export default router;
