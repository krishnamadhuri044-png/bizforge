/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Rocket, 
  Type, 
  Megaphone, 
  Smile, 
  Palette, 
  MessageSquare, 
  Image as ImageIcon,
  ChevronRight,
  Loader2,
  ArrowLeft,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Page = 'home' | 'brand' | 'marketing' | 'sentiment' | 'palette' | 'chatbot' | 'logo';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home': return <HomePage onNavigate={setCurrentPage} />;
      case 'brand': return <BrandGenerator onBack={() => setCurrentPage('home')} />;
      case 'marketing': return <MarketingGenerator onBack={() => setCurrentPage('home')} />;
      case 'sentiment': return <SentimentAnalyzer onBack={() => setCurrentPage('home')} />;
      case 'palette': return <PaletteGenerator onBack={() => setCurrentPage('home')} />;
      case 'chatbot': return <BrandingChatbot onBack={() => setCurrentPage('home')} />;
      case 'logo': return <LogoPromptGenerator onBack={() => setCurrentPage('home')} />;
      default: return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-emerald-500/30">
      {/* Header */}
      <header className="border-b border-zinc-800/50 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div 
            className="flex items-center gap-2 cursor-pointer group"
            onClick={() => setCurrentPage('home')}
          >
            <div className="p-2 bg-emerald-500 rounded-lg group-hover:rotate-12 transition-transform">
              <Rocket className="w-5 h-5 text-zinc-950" />
            </div>
            <span className="text-xl font-bold tracking-tight">BizForge</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-zinc-400">
            <button onClick={() => setCurrentPage('brand')} className="hover:text-emerald-400 transition-colors">Brand</button>
            <button onClick={() => setCurrentPage('marketing')} className="hover:text-emerald-400 transition-colors">Marketing</button>
            <button onClick={() => setCurrentPage('chatbot')} className="hover:text-emerald-400 transition-colors">Chat</button>
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/50 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-zinc-500 text-sm">
            © 2026 BizForge AI Branding Platform. Powered by Llama 3.3 & IBM Granite.
          </p>
        </div>
      </footer>
    </div>
  );
}

function HomePage({ onNavigate }: { onNavigate: (page: Page) => void }) {
  const tools = [
    { id: 'brand', name: 'Brand Name Generator', desc: 'Creative names for your next big idea.', icon: Type, color: 'text-blue-400' },
    { id: 'marketing', name: 'Marketing Content', desc: 'High-converting copy for your products.', icon: Megaphone, color: 'text-purple-400' },
    { id: 'sentiment', name: 'Sentiment Analysis', desc: 'Understand your customers better.', icon: Smile, color: 'text-yellow-400' },
    { id: 'palette', name: 'Color Palette', desc: 'Visual identity designed by AI.', icon: Palette, color: 'text-pink-400' },
    { id: 'chatbot', name: 'Branding Chatbot', desc: 'Expert advice on your brand strategy.', icon: MessageSquare, color: 'text-emerald-400' },
    { id: 'logo', name: 'Logo Prompt Gen', desc: 'Perfect prompts for AI logo design.', icon: ImageIcon, color: 'text-orange-400' },
  ];

  return (
    <div className="space-y-12">
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <motion.h1 
          className="text-5xl md:text-7xl font-bold tracking-tighter bg-gradient-to-b from-white to-zinc-500 bg-clip-text text-transparent"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          Forge Your Brand with AI
        </motion.h1>
        <p className="text-zinc-400 text-lg md:text-xl">
          The all-in-one branding suite powered by state-of-the-art AI models. 
          From naming to strategy, we've got you covered.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.map((tool) => (
          <motion.div
            key={tool.id}
            whileHover={{ y: -4 }}
            className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-emerald-500/50 transition-all cursor-pointer group"
            onClick={() => onNavigate(tool.id as Page)}
          >
            <div className={`p-3 rounded-xl bg-zinc-950 w-fit mb-4 group-hover:scale-110 transition-transform`}>
              <tool.icon className={`w-6 h-6 ${tool.color}`} />
            </div>
            <h3 className="text-xl font-semibold mb-2 flex items-center gap-2">
              {tool.name}
              <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
            </h3>
            <p className="text-zinc-400 text-sm leading-relaxed">
              {tool.desc}
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function BrandGenerator({ onBack }: { onBack: () => void }) {
  const [industry, setIndustry] = useState('');
  const [keywords, setKeywords] = useState('');
  const [tone, setTone] = useState('Professional');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<string[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/brand/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ industry, keywords, tone }),
      });
      const data = await res.json();
      setResults(data.names || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <button onClick={onBack} className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Home
      </button>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Brand Name Generator</h2>
        <p className="text-zinc-400">Discover the perfect name for your business.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 bg-zinc-900 p-8 rounded-2xl border border-zinc-800">
        <div className="space-y-2">
          <label className="text-sm font-medium text-zinc-300">Industry</label>
          <input 
            type="text" 
            value={industry}
            onChange={(e) => setIndustry(e.target.value)}
            placeholder="e.g. Fintech, Sustainable Fashion"
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            required
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-zinc-300">Keywords</label>
          <input 
            type="text" 
            value={keywords}
            onChange={(e) => setKeywords(e.target.value)}
            placeholder="e.g. speed, trust, green, modern"
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            required
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-zinc-300">Tone</label>
          <select 
            value={tone}
            onChange={(e) => setTone(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
          >
            <option>Professional</option>
            <option>Playful</option>
            <option>Minimalist</option>
            <option>Luxury</option>
            <option>Futuristic</option>
          </select>
        </div>
        <button 
          type="submit" 
          disabled={loading}
          className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
          Generate Names
        </button>
      </form>

      {results.length > 0 && (
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 sm:grid-cols-2 gap-4"
        >
          {results.map((name, i) => (
            <div key={i} className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl text-center font-medium hover:border-emerald-500/30 transition-colors">
              {name}
            </div>
          ))}
        </motion.div>
      )}
    </div>
  );
}

function MarketingGenerator({ onBack }: { onBack: () => void }) {
  const [description, setDescription] = useState('');
  const [tone, setTone] = useState('Professional');
  const [type, setType] = useState('Product Description');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/marketing/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description, tone, type }),
      });
      const data = await res.json();
      setResult(data.content || '');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <button onClick={onBack} className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Home
      </button>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Marketing Content</h2>
        <p className="text-zinc-400">Craft compelling copy that converts.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 bg-zinc-900 p-8 rounded-2xl border border-zinc-800">
        <div className="space-y-2">
          <label className="text-sm font-medium text-zinc-300">Brand/Product Description</label>
          <textarea 
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe what you're selling or your brand mission..."
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all min-h-[120px]"
            required
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-zinc-300">Content Type</label>
            <select 
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            >
              <option>Product Description</option>
              <option>Ad Copy</option>
              <option>Social Media Post</option>
              <option>Email Subject Line</option>
              <option>Tagline</option>
            </select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-zinc-300">Tone</label>
            <select 
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            >
              <option>Professional</option>
              <option>Witty</option>
              <option>Persuasive</option>
              <option>Empathetic</option>
              <option>Urgent</option>
            </select>
          </div>
        </div>
        <button 
          type="submit" 
          disabled={loading}
          className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
          Generate Content
        </button>
      </form>

      {result && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }} 
          animate={{ opacity: 1, y: 0 }}
          className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl whitespace-pre-wrap leading-relaxed text-zinc-300"
        >
          {result}
        </motion.div>
      )}
    </div>
  );
}

function SentimentAnalyzer({ onBack }: { onBack: () => void }) {
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ sentiment: string, explanation: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/sentiment/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text }),
      });
      const data = await res.json();
      setResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getSentimentColor = (s: string) => {
    switch (s.toLowerCase()) {
      case 'positive': return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20';
      case 'negative': return 'text-red-400 bg-red-400/10 border-red-400/20';
      default: return 'text-zinc-400 bg-zinc-400/10 border-zinc-400/20';
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <button onClick={onBack} className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Home
      </button>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Sentiment Analysis</h2>
        <p className="text-zinc-400">Analyze customer feedback with AI precision.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 bg-zinc-900 p-8 rounded-2xl border border-zinc-800">
        <div className="space-y-2">
          <label className="text-sm font-medium text-zinc-300">Review Text</label>
          <textarea 
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Paste a customer review or feedback here..."
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all min-h-[120px]"
            required
          />
        </div>
        <button 
          type="submit" 
          disabled={loading}
          className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Smile className="w-5 h-5" />}
          Analyze Sentiment
        </button>
      </form>

      {result && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }} 
          animate={{ opacity: 1, y: 0 }}
          className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-4"
        >
          <div className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border ${getSentimentColor(result.sentiment)}`}>
            {result.sentiment}
          </div>
          <p className="text-zinc-300 leading-relaxed">
            {result.explanation}
          </p>
        </motion.div>
      )}
    </div>
  );
}

function PaletteGenerator({ onBack }: { onBack: () => void }) {
  const [industry, setIndustry] = useState('');
  const [tone, setTone] = useState('Modern');
  const [loading, setLoading] = useState(false);
  const [palette, setPalette] = useState<{ hex: string, name: string }[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/palette/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ industry, tone }),
      });
      const data = await res.json();
      setPalette(data.palette || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <button onClick={onBack} className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Home
      </button>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Color Palette Generator</h2>
        <p className="text-zinc-400">AI-suggested color schemes for your brand.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 bg-zinc-900 p-8 rounded-2xl border border-zinc-800">
        <div className="space-y-2">
          <label className="text-sm font-medium text-zinc-300">Industry</label>
          <input 
            type="text" 
            value={industry}
            onChange={(e) => setIndustry(e.target.value)}
            placeholder="e.g. Coffee Shop, Tech Startup"
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            required
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-zinc-300">Tone</label>
          <select 
            value={tone}
            onChange={(e) => setTone(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
          >
            <option>Modern</option>
            <option>Earthy</option>
            <option>High-Tech</option>
            <option>Warm</option>
            <option>Corporate</option>
          </select>
        </div>
        <button 
          type="submit" 
          disabled={loading}
          className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Palette className="w-5 h-5" />}
          Generate Palette
        </button>
      </form>

      {palette.length > 0 && (
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }}
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4"
        >
          {palette.map((color, i) => (
            <div key={i} className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden group">
              <div 
                className="h-24 w-full transition-transform group-hover:scale-105" 
                style={{ backgroundColor: color.hex }}
              />
              <div className="p-4">
                <p className="font-bold text-sm">{color.name}</p>
                <p className="text-zinc-500 text-xs font-mono uppercase">{color.hex}</p>
              </div>
            </div>
          ))}
        </motion.div>
      )}
    </div>
  );
}

function BrandingChatbot({ onBack }: { onBack: () => void }) {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai', text: string }[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const res = await fetch('/api/chatbot/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: userMsg }),
      });
      const data = await res.json();
      setMessages(prev => [...prev, { role: 'ai', text: data.response || 'Sorry, I encountered an error.' }]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 h-[70vh] flex flex-col">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Home
        </button>
        <div className="flex items-center gap-2 text-xs font-bold text-zinc-500 uppercase tracking-widest">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          IBM Granite Active
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto space-y-4 p-4 bg-zinc-900/50 rounded-2xl border border-zinc-800/50 scrollbar-hide">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50">
            <MessageSquare className="w-12 h-12" />
            <p>Ask me anything about your brand strategy.</p>
          </div>
        )}
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-4 rounded-2xl ${
              msg.role === 'user' 
                ? 'bg-emerald-500 text-zinc-950 font-medium' 
                : 'bg-zinc-800 text-zinc-100 border border-zinc-700'
            }`}>
              {msg.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-zinc-800 p-4 rounded-2xl border border-zinc-700">
              <Loader2 className="w-5 h-5 animate-spin" />
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your branding question..."
          className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
        />
        <button 
          type="submit" 
          disabled={loading}
          className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 p-3 rounded-xl transition-all disabled:opacity-50"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </form>
    </div>
  );
}

function LogoPromptGenerator({ onBack }: { onBack: () => void }) {
  const [brandName, setBrandName] = useState('');
  const [industry, setIndustry] = useState('');
  const [keywords, setKeywords] = useState('');
  const [loading, setLoading] = useState(false);
  const [prompt, setPrompt] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/logo/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ brandName, industry, keywords }),
      });
      const data = await res.json();
      setPrompt(data.prompt || '');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <button onClick={onBack} className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Home
      </button>
      
      <div className="space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Logo Prompt Generator</h2>
        <p className="text-zinc-400">Generate high-quality prompts for Stable Diffusion XL.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 bg-zinc-900 p-8 rounded-2xl border border-zinc-800">
        <div className="space-y-2">
          <label className="text-sm font-medium text-zinc-300">Brand Name</label>
          <input 
            type="text" 
            value={brandName}
            onChange={(e) => setBrandName(e.target.value)}
            placeholder="e.g. BizForge"
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            required
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-zinc-300">Industry</label>
          <input 
            type="text" 
            value={industry}
            onChange={(e) => setIndustry(e.target.value)}
            placeholder="e.g. AI Software"
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            required
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-zinc-300">Keywords/Style</label>
          <input 
            type="text" 
            value={keywords}
            onChange={(e) => setKeywords(e.target.value)}
            placeholder="e.g. minimalist, geometric, blue and white"
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all"
            required
          />
        </div>
        <button 
          type="submit" 
          disabled={loading}
          className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ImageIcon className="w-5 h-5" />}
          Generate Prompt
        </button>
      </form>

      {prompt && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }} 
          animate={{ opacity: 1, y: 0 }}
          className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-4"
        >
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold uppercase tracking-widest text-zinc-500">Generated Prompt</h4>
            <button 
              onClick={() => navigator.clipboard.writeText(prompt)}
              className="text-xs text-emerald-400 hover:underline"
            >
              Copy to Clipboard
            </button>
          </div>
          <p className="text-zinc-300 leading-relaxed italic">
            "{prompt}"
          </p>
        </motion.div>
      )}
    </div>
  );
}
